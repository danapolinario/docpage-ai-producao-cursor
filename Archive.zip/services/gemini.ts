
import { GoogleGenAI, Type } from "@google/genai";
import { BriefingData, LandingPageContent, DesignSettings, SectionVisibility, AIModificationResponse } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const LP_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    headline: { type: Type.STRING, description: "A catchy main headline for the hero section." },
    subheadline: { type: Type.STRING, description: "A supporting subheadline explaining the value proposition." },
    ctaText: { type: Type.STRING, description: "Text for the main Call to Action button." },
    aboutTitle: { type: Type.STRING, description: "Title for the About Doctor section." },
    aboutBody: { type: Type.STRING, description: "Biographical text about the doctor, building trust." },
    servicesTitle: { type: Type.STRING, description: "Title for the Services section." },
    services: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
        },
      },
      description: "List of 3-4 main medical services offered.",
    },
    testimonials: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          text: { type: Type.STRING },
        },
      },
      description: "2-3 fictional testimonials validating the doctor's expertise.",
    },
    footerText: { type: Type.STRING, description: "Footer copyright and small text." },
    contactEmail: { type: Type.STRING },
    contactPhone: { type: Type.STRING },
    contactAddresses: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: ["headline", "subheadline", "ctaText", "aboutTitle", "aboutBody", "services", "testimonials", "footerText"],
};

// Expanded Schema for Refinement that includes visual aspects
const MODIFICATION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    content: LP_SCHEMA,
    design: {
      type: Type.OBJECT,
      properties: {
        colorPalette: { type: Type.STRING, enum: ['blue', 'green', 'slate', 'rose', 'indigo'] },
        secondaryColor: { type: Type.STRING, enum: ['orange', 'teal', 'purple', 'gold', 'gray'] },
        fontPairing: { type: Type.STRING, enum: ['sans', 'serif-sans', 'mono-sans'] },
        borderRadius: { type: Type.STRING, enum: ['none', 'medium', 'full'] },
        photoStyle: { type: Type.STRING, enum: ['minimal', 'organic', 'framed', 'glass', 'floating', 'arch', 'rotate', 'collage'] },
      },
      description: "Only include fields that need to change based on the user request."
    },
    visibility: {
      type: Type.OBJECT,
      properties: {
        hero: { type: Type.BOOLEAN },
        services: { type: Type.BOOLEAN },
        about: { type: Type.BOOLEAN },
        testimonials: { type: Type.BOOLEAN },
        footer: { type: Type.BOOLEAN },
      },
      description: "Only include fields that need to change based on the user request."
    }
  }
};

// Helper to clean JSON string from Markdown code blocks
const cleanJsonString = (text: string): string => {
  return text.replace(/^```json\s*/, '').replace(/^```\s*/, '').replace(/\s*```$/, '');
};

export const generateLandingPageContent = async (
  briefing: BriefingData
): Promise<LandingPageContent> => {
  const prompt = `
    You are an expert medical copywriter. Create content for a high-converting landing page for a doctor.
    
    Briefing Details:
    - Name: ${briefing.name}
    - Specialty: ${briefing.specialty}
    - Target Audience: ${briefing.targetAudience}
    - Services: ${briefing.mainServices}
    - Bio/Background: ${briefing.bio || "N/A"}
    - Tone: ${briefing.tone}
    - Locations: ${briefing.addresses?.join(', ') || "N/A"}

    CRITICAL COMPLIANCE RULES (CFM Resolution 2.336/2023 - STRICT):
    1. NEVER use words like "Garantido", "Melhor do país", "Cura definitiva", "Sem riscos", "100% eficaz", "Milagroso".
    2. Do NOT promise specific results (e.g., "Lose 10kg in 1 week").
    3. Use educational and objective language (e.g., "Treatment indicated for...", "Evaluation required").
    4. Call to Actions (CTA) must be neutral: "Agendar Consulta", "Marcar Avaliação", "Entrar em Contato". Do NOT use "Compre Agora".
    5. In the services descriptions, explain WHAT the procedure is, do not sell the result.
    6. Ensure the tone builds trust but respects medical ethics.

    Keep the tone professional yet approachable. 
    Use the provided bio to create a compelling 'About' section.
    Include the contact info provided in the briefing.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: LP_SCHEMA,
      },
    });

    if (!response.text) throw new Error("No text returned from API");
    return JSON.parse(cleanJsonString(response.text)) as LandingPageContent;
  } catch (error) {
    console.error("Error generating LP content:", error);
    throw error;
  }
};

export const enhancePhoto = async (base64Image: string): Promise<string> => {
  const base64Data = base64Image.split(',')[1] || base64Image;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Data,
            },
          },
          {
            text: "Generate a high-quality, professional headshot of this person suitable for a medical profile. The background should be a blurred, clean, modern medical office or neutral studio background. The lighting should be soft and professional. The person should look confident, trustworthy, and modest. Avoid any suggestive poses. Maintain the facial features of the original person but improve the image quality and attire if necessary (white coat or professional suit).",
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/jpeg;base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Error enhancing photo:", error);
    throw error;
  }
};

export const generateOfficePhoto = async (base64Image: string): Promise<string> => {
  const base64Data = base64Image.split(',')[1] || base64Image;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Data,
            },
          },
          {
            text: "A cinematic medium shot of this doctor standing confidently in a modern, clean, bright medical consulting room or office. The doctor is wearing a professional white coat or suit. The background shows a medical desk, books, and maybe a blurred medical chart or anatomical model, creating a context of authority and care. Warm, welcoming lighting. Maintain identity consistency.",
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/jpeg;base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Error generating office photo:", error);
    throw error;
  }
};

export const refineLandingPage = async (
  currentContent: LandingPageContent,
  currentDesign: DesignSettings,
  currentVisibility: SectionVisibility,
  instruction: string
): Promise<AIModificationResponse> => {
  const prompt = `
    You are an expert Landing Page Designer and Copywriter assistant. 
    The user wants to modify their page. You can change the TEXT content, the VISUAL DESIGN, or the VISIBILITY of sections.

    Current State:
    - Content: ${JSON.stringify(currentContent)}
    - Design Settings: ${JSON.stringify(currentDesign)}
    - Section Visibility: ${JSON.stringify(currentVisibility)}

    User Instruction: "${instruction}"

    Instructions:
    1. Interpret the user's intent. 
       - If they say "make it blue" or "round buttons", update 'design'.
       - If they say "hide testimonials", update 'visibility'.
       - If they say "rewrite the headline", update 'content'.
    2. Return a JSON object with ONLY the parts that need to change.
    3. If changing content, return the FULL content object with the specific fields updated.
    4. If changing design or visibility, you can return partial objects.
    
    Compliance Reminder: Do NOT allow any changes that violate medical advertising ethics (no sensationalism).

    Available Design Options:
    - colorPalette: blue, green, slate, rose, indigo
    - secondaryColor: orange, teal, purple, gold, gray
    - fontPairing: sans, serif-sans, mono-sans
    - borderRadius: none, medium, full
    - photoStyle: minimal, organic, framed, glass, floating, arch, rotate, collage
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: MODIFICATION_SCHEMA,
      },
    });

    if (!response.text) throw new Error("No text returned from API");
    return JSON.parse(cleanJsonString(response.text)) as AIModificationResponse;
  } catch (error) {
    console.error("Error refining content:", error);
    throw error;
  }
};

const FORBIDDEN_TERMS = [
  { regex: /\b(garantido|garantia|garantimos)\b/gi, replacement: "focado em resultados" },
  { regex: /\b(cura|curar|cura definitiva)\b/gi, replacement: "tratamento" },
  { regex: /\b(100%|cem por cento|totalmente eficaz)\b/gi, replacement: "eficaz" },
  { regex: /\b(o melhor|a melhor|o único|a única)\b/gi, replacement: "referência" },
  { regex: /\b(sem riscos|sem dor|sem efeitos colaterais)\b/gi, replacement: "minimamente invasivo" },
  { regex: /\b(promoção|desconto|off|imperdível|compre agora)\b/gi, replacement: "condições especiais" },
  { regex: /\b(milagre|milagroso|mágico|imediato)\b/gi, replacement: "avançado" },
  { regex: /\b(antes e depois)\b/gi, replacement: "casos clínicos" },
];

const scrubText = (text: string): string => {
  if (!text) return "";
  let cleaned = text;
  FORBIDDEN_TERMS.forEach(({ regex, replacement }) => {
    cleaned = cleaned.replace(regex, replacement);
  });
  return cleaned;
};

export const sanitizeContent = (data: any): LandingPageContent => {
  return {
    headline: scrubText(typeof data?.headline === 'string' ? data.headline : ""),
    subheadline: scrubText(typeof data?.subheadline === 'string' ? data.subheadline : ""),
    ctaText: scrubText(typeof data?.ctaText === 'string' ? data.ctaText : ""),
    aboutTitle: scrubText(typeof data?.aboutTitle === 'string' ? data.aboutTitle : ""),
    aboutBody: scrubText(typeof data?.aboutBody === 'string' ? data.aboutBody : ""),
    servicesTitle: scrubText(typeof data?.servicesTitle === 'string' ? data.servicesTitle : ""),
    services: Array.isArray(data?.services) 
      ? data.services.map((s: any) => ({
          title: scrubText(s.title),
          description: scrubText(s.description)
        })) 
      : [],
    testimonials: Array.isArray(data?.testimonials) 
      ? data.testimonials.map((t: any) => ({
          name: t.name,
          text: scrubText(t.text)
        })) 
      : [],
    footerText: typeof data?.footerText === 'string' ? data.footerText : "",
    contactEmail: typeof data?.contactEmail === 'string' ? data.contactEmail : undefined,
    contactPhone: typeof data?.contactPhone === 'string' ? data.contactPhone : undefined,
    contactAddresses: Array.isArray(data?.contactAddresses) 
      ? data.contactAddresses 
      : (typeof data?.contactAddress === 'string' ? [data.contactAddress] : []),
    contactAddress: typeof data?.contactAddress === 'string' ? data.contactAddress : undefined
  };
};
