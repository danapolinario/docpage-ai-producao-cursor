import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

export interface AuthUser {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

/**
 * Enviar código OTP para o email
 * Se o usuário não existir, será criado automaticamente
 */
export async function sendOTP(email: string, name?: string) {
  const { data, error } = await supabase.auth.signInWithOtp({
    email,
    options: {
      // Email template personalizado (opcional)
      emailRedirectTo: undefined,
      // Metadados do usuário (usado se for novo usuário)
      data: {
        name: name || email.split('@')[0],
      },
    },
  });

  if (error) throw error;
  return data;
}

/**
 * Verificar código OTP e autenticar usuário
 */
export async function verifyOTP(email: string, token: string) {
  const { data, error } = await supabase.auth.verifyOtp({
    email,
    token,
    type: 'email', // tipo de OTP
  });

  if (error) throw error;
  return data;
}

/**
 * Reenviar código OTP
 */
export async function resendOTP(email: string) {
  return sendOTP(email);
}

/**
 * Registrar novo usuário (agora usa OTP)
 * Envia código para email
 */
export async function signUp(
  email: string,
  name?: string
) {
  // Com OTP, signUp apenas envia o código
  // O usuário será criado quando verificar o código
  return sendOTP(email, name);
}

/**
 * Login com OTP (enviar código)
 * Para login e cadastro, o fluxo é o mesmo: enviar código
 */
export async function signIn(email: string) {
  // Com OTP, signIn apenas envia o código
  return sendOTP(email);
}

/**
 * Verificar código e autenticar (comum para login e cadastro)
 */
export async function verifyCode(email: string, code: string) {
  return verifyOTP(email, code);
}

/**
 * Logout
 */
export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

/**
 * Obter usuário atual
 */
export async function getCurrentUser(): Promise<User | null> {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

/**
 * Verificar se está autenticado
 */
export async function isAuthenticated(): Promise<boolean> {
  const user = await getCurrentUser();
  return !!user;
}

/**
 * Observar mudanças de autenticação
 * Útil para atualizar UI quando usuário faz login/logout
 */
export function onAuthStateChange(
  callback: (user: User | null) => void
) {
  return supabase.auth.onAuthStateChange((event, session) => {
    callback(session?.user || null);
  });
}

/**
 * Obter sessão atual
 */
export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}
