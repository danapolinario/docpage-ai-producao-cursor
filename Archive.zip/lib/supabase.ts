import { createClient } from '@supabase/supabase-js';

// Obter variáveis de ambiente
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Validar variáveis de ambiente
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Variáveis de ambiente do Supabase não configuradas. ' +
    'Verifique se VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY estão definidas no arquivo .env.local'
  );
}

// Criar cliente Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Tipos para o banco de dados (serão gerados automaticamente depois)
export type Database = {
  public: {
    Tables: {
      landing_pages: {
        Row: {
          id: string;
          user_id: string;
          subdomain: string;
          custom_domain: string | null;
          slug: string;
          briefing_data: any;
          content_data: any;
          design_settings: any;
          section_visibility: any;
          layout_variant: number;
          photo_url: string | null;
          about_photo_url: string | null;
          meta_title: string | null;
          meta_description: string | null;
          meta_keywords: string[] | null;
          og_image_url: string | null;
          schema_markup: any;
          status: 'draft' | 'published' | 'archived';
          published_at: string | null;
          view_count: number;
          last_viewed_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          subdomain: string;
          custom_domain?: string | null;
          slug: string;
          briefing_data: any;
          content_data: any;
          design_settings: any;
          section_visibility: any;
          layout_variant?: number;
          photo_url?: string | null;
          about_photo_url?: string | null;
          meta_title?: string | null;
          meta_description?: string | null;
          meta_keywords?: string[] | null;
          og_image_url?: string | null;
          schema_markup?: any;
          status?: 'draft' | 'published' | 'archived';
          published_at?: string | null;
          view_count?: number;
          last_viewed_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          subdomain?: string;
          custom_domain?: string | null;
          slug?: string;
          briefing_data?: any;
          content_data?: any;
          design_settings?: any;
          section_visibility?: any;
          layout_variant?: number;
          photo_url?: string | null;
          about_photo_url?: string | null;
          meta_title?: string | null;
          meta_description?: string | null;
          meta_keywords?: string[] | null;
          og_image_url?: string | null;
          schema_markup?: any;
          status?: 'draft' | 'published' | 'archived';
          published_at?: string | null;
          view_count?: number;
          last_viewed_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      analytics_events: {
        Row: {
          id: string;
          landing_page_id: string;
          event_type: string;
          event_data: any;
          ip_address: string | null;
          user_agent: string | null;
          referrer: string | null;
          country: string | null;
          city: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          landing_page_id: string;
          event_type: string;
          event_data?: any;
          ip_address?: string | null;
          user_agent?: string | null;
          referrer?: string | null;
          country?: string | null;
          city?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          landing_page_id?: string;
          event_type?: string;
          event_data?: any;
          ip_address?: string | null;
          user_agent?: string | null;
          referrer?: string | null;
          country?: string | null;
          city?: string | null;
          created_at?: string;
        };
      };
      custom_domains: {
        Row: {
          id: string;
          landing_page_id: string;
          domain: string;
          ssl_status: string;
          dns_configured: boolean;
          verified: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          landing_page_id: string;
          domain: string;
          ssl_status?: string;
          dns_configured?: boolean;
          verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          landing_page_id?: string;
          domain?: string;
          ssl_status?: string;
          dns_configured?: boolean;
          verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};
